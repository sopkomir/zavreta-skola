import fs from "node:fs";

const xml = fs.readFileSync("exports/wordpress.xml", "utf8");
const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].map((x) => x[1]);

function tag(source, name) {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(
    "<" + escaped + "[^>]*>\\s*(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?\\s*<\\/" + escaped + ">",
    "i"
  );
  const match = re.exec(source);
  return match ? clean(match[1]) : "";
}

function clean(value) {
  return String(value || "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function slugify(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
}

function categories(source) {
  return [...source.matchAll(/<category\s+domain="([^"]+)"\s+nicename="([^"]+)"[^>]*>\s*(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?\s*<\/category>/g)]
    .map((m) => ({
      domain: m[1],
      slug: m[2],
      name: clean(m[3]),
    }));
}

const data = [];
let fallback = 0;

for (const item of items) {
  if (!item.includes("<wp:post_type><![CDATA[classified]]></wp:post_type>")) continue;
  if (!item.includes("<wp:status><![CDATA[publish]]></wp:status>")) continue;

  const title = tag(item, "title") || "Bez názvu";
  const cats = categories(item);
  const slug = tag(item, "wp:post_name") || slugify(title) || `zdroj-${++fallback}`;

  data.push({
    title,
    slug,
    date: tag(item, "wp:post_date").slice(0, 10),
    url: tag(item, "link"),
    description: tag(item, "content:encoded").slice(0, 320),
    category: cats.find((c) => c.domain === "ad_category")?.name || "",
    type: cats.find((c) => c.domain === "ad_type")?.name || "",
    allCategories: cats,
  });
}

fs.mkdirSync("src/data", { recursive: true });
fs.writeFileSync("src/data/zdroje.json", JSON.stringify(data, null, 2), "utf8");

console.log("Vytvorene src/data/zdroje.json");
console.log("Pocet zdrojov:", data.length);
console.log("Prvych 5:");
console.log(data.slice(0, 5));